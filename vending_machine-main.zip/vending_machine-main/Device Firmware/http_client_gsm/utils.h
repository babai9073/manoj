#include <Arduino.h>
#include <pdulib.h>
#include <SPIFFS.h>
#include "BluetoothSerial.h"

BluetoothSerial SerialBT;
#define BUFFER_SIZE 200
PDU mypdu = PDU(BUFFER_SIZE);

String PHONE = "";
String msg = "";

// Modified: Use HardwareSerial for GSM (UART2: RX2=16, TX2=17 on ESP32)
HardwareSerial GSMSerial(2);  // RX2=16, TX2=17 (default for ESP32), change if needed

void ShowSerialData() {
  while (GSMSerial.available()) {
    char c = GSMSerial.read();
    SerialBT.write(c); // Send the data to Bluetooth serial
    Serial.write(c);   // Optionally, also send the data to USB serial
  }
}

void sendATCommand(String command, int delayTime) {
  GSMSerial.println(command);
  delay(delayTime);
  ShowSerialData();
}

void initSPIFFS() {
  if (!SPIFFS.begin(true)) {
    Serial.println("Failed to mount SPIFFS");
    return;
  }
  Serial.println("SPIFFS mounted successfully");
}

void storeString(const char* filename, String a_str) {
  char data[a_str.length() + 1];
  a_str.toCharArray(data, sizeof(data));
  File file = SPIFFS.open(filename, "w");
  if (!file) {
    Serial.println("Failed to open file for writing");
    return;
  }
  file.println(data);
  file.close();
  Serial.println("String stored successfully");
}

String readString(const char* filename) {
  File file = SPIFFS.open(filename, "r");
  if (!file) {
    Serial.println("Failed to open file for reading");
    return String();
  }
  String data = file.readString();
  file.close();
  return data;
}

void deleteFile(const char* filename) {
  if (SPIFFS.exists(filename)) {
    SPIFFS.remove(filename);
    Serial.println("File deleted successfully");
  } else {
    Serial.println("File does not exist");
  }
}

String concatenateString(String input) {
    String concatenatedString = "";
    for (int i = 0; i < input.length(); i++) {
        char currentChar = input.charAt(i);
        if (currentChar != ' ' && currentChar != '\n' && currentChar != '\r') {
            concatenatedString += currentChar;
        }
    }
    return concatenatedString;
}

std::pair<String, String> decodePDUMessage() {
  String pduString = readString("/data.txt");
  std::pair<String, String> result;
  if (mypdu.decodePDU(pduString.c_str())) {
    if (mypdu.getOverflow()) {
      Serial.println("Buffer Overflow, partial message only");
    }
    result.first = mypdu.getSender();
    result.second = mypdu.getText();
  } else {
    Serial.println("Decode failed");
  }
  deleteFile("/data.txt");
  return result;
}

bool isSubstringPresent(const String& mainString, const String& substring) {
  int found = mainString.indexOf(substring);
  return (found != -1);
}

void smsRead() {
  GSMSerial.println("AT");
  GSMSerial.println("AT+CMGF=0");
  GSMSerial.println("AT+CNMI=1,2,0,0,0");
  delay(2000);
}

std::pair<String, String> parseData(String buff) {
  PHONE = "";
  msg = "";

  unsigned int index;

  index = buff.indexOf("\r");
  buff.remove(0, index + 2);
  buff.trim();

  if (buff != "OK") {
    index = buff.indexOf(":");
    String cmd = buff.substring(0, index);
    cmd.trim();

    buff.remove(0, index + 2);

    if (cmd == "+CMT") {
      index = buff.lastIndexOf(0x0D);
      msg = buff.substring(index + 2, buff.length());
      msg.toLowerCase();
      index = buff.indexOf(0x22);
      PHONE = buff.substring(index + 1, index + 14);
    }
  }
  return std::make_pair(msg, PHONE);
}

int readInteger(const char* path) {
  if (!SPIFFS.exists(path)) {
    File file = SPIFFS.open(path, "w");
    if (!file) {
      Serial.printf("Failed to create file: %s\n", path);
      return 0;
    }
    file.println("0");
    file.close();
  }
  File file = SPIFFS.open(path, "r");
  if (!file) {
    Serial.printf("Failed to open file: %s\n", path);
    return 0;
  }
  int value = file.parseInt();
  file.close();
  return value;
}

void storeInteger(const char* path, int value) {
  File file = SPIFFS.open(path, "w");
  if (!file) {
    Serial.printf("Failed to open file for writing: %s\n", path);
    return;
  }
  file.println(value);
  file.close();
}

String removeNewlines(String input) {
  String result = "";
  for (int i = 0; i < input.length(); i++) {
    char c = input.charAt(i);
    if (c != '\n' && c != '\r') {
      result += c;
    }
  }
  return result;
}