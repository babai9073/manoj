import qrcode

def generate_upi_qr_code(vpa, name, amount, currency="INR", message=""):
    # UPI URL format
    upi_url = f"upi://pay?pa={vpa}&pn={name}&mc=&tid=&tr=&tn={message}&am={amount}&cu={currency}"

    # Generate QR code
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(upi_url)
    qr.make(fit=True)

    qr_image = qr.make_image(fill_color="black", back_color="white")
    qr_image.save("upi_qr_code_1.png")

    return qr_image


vpa = "dhritiman.pantu@oksbi"  
name = "Dhritiman Dasgupta"  
amount = "10.00"  # Replace with the payment amount
message = "Payment for goods/services"  # Replace with a transaction note (optional)

generate_upi_qr_code(vpa, name, amount, message=message)
