from PIL import Image

def convert_qr_to_bitmap(image_path, resolution=(300, 300)):
    img = Image.open(image_path)

    # Change the resolution if needed
    img = img.resize(resolution)  # Use resample parameter

    # Convert the image to bitmap
    img = img.convert("1")  # "1" mode for 1-bit pixels, representing black and white

    # Save the bitmap image
    bitmap_path = "upi_qr_code_bitmap.bmp"
    img.save(bitmap_path)

    return bitmap_path

# Example usage:
image_path = "upi_qr_code.png"  # Replace with the path to your QR code image
new_resolution = (65,65)  # Replace with your desired resolution (width, height)

bitmap_path = convert_qr_to_bitmap(image_path, new_resolution)

# Now, 'bitmap_path' contains the path to the saved bitmap image.
