import qrcode
from PIL import Image

def generate_upi_qr_code(vpa, name, amount, currency="INR", message=""):
    # UPI URL format
    upi_url = f"upi://pay?pa={vpa}&pn={name}&mc=&tid=&tr=&tn={message}&am={amount}&cu={currency}"

    # Generate QR code
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(upi_url)
    qr.make(fit=True)

    qr_image = qr.make_image(fill_color="black", back_color="white")
    qr_image.save("upi_qr_code.png")  # Save the QR code image

    return qr_image

def convert_qr_to_bitmap(image_path, resolution=(300, 300)):
    img = Image.open(image_path)
    img = img.resize(resolution)
    img = img.convert("1")
    global mcid
    bitmap_path = f"{mcid}.bmp"
    img.save(bitmap_path)

    return bitmap_path


def generate_and_convert_upi_qr(vpa, name, amount, currency="INR", message="", qr_resolution=(70, 70), bitmap_resolution=(70, 70)):
    generate_upi_qr_code(vpa, name, amount, currency, message)
    bitmap_path = convert_qr_to_bitmap("upi_qr_code.png", resolution=bitmap_resolution)

    return bitmap_path

def convert_qr_to_xbm(image_path, xbm_file, resolution=(70, 70)):
    img = Image.open(image_path)
    img = img.resize(resolution) 
    img = img.convert("1") 
    img.save(xbm_file)

    return xbm_file



vpa = "Pos.11320676@indus"
mcid="ACBVM96"; 
name = "CLOTH BAG VENDING MACHINE"  
amount = "10.00"  
message = "Payment for CLoth Bag" 
bitmap_path = generate_and_convert_upi_qr(vpa, name, amount, message=message)
print("Bitmap image saved at:", bitmap_path)

