import csv
import mod_1
def read_vpa_from_csv(file_path):
    with open(file_path, 'r') as file:
        reader = csv.DictReader(file)
        for row in reader:
            vpa = row['VPA no']
            print(vpa)  # You can modify this line to do something with the vpa value 
            name = "CLOTH BAG VENDING MACHINE"  
            amount = "1.00"  
            message = "Payment for CLoth Bag" 
            xbm_path = mod_1.generate_and_convert_upi_qr(vpa, name, amount, message=message)
            print("XBM image saved at:", xbm_path)


# Example usage
file_path = 'f2.csv'
read_vpa_from_csv(file_path)
