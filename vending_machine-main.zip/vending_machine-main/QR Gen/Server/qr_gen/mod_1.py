import os
import qrcode
from PIL import Image

def generate_upi_qr_code(vpa, name, amount, currency="INR", message=""):
    # UPI URL format
    upi_url = f"upi://pay?pa={vpa}&pn={name}&mc=&tid=&tr=&tn={message}&am={amount}&cu={currency}"

    # Generate QR code
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=0,  # Set border to 0 to remove the black border
    )
    qr.add_data(upi_url)
    qr.make(fit=True)

    qr_image = qr.make_image(fill_color="black", back_color="white")
    
    # Find the bounding box of the QR code
    bbox = qr_image.getbbox()
    # Crop the QR code image to remove the extra white space
    qr_image = qr_image.crop(bbox)

    qr_image.save("upi_qr_code.png")  # Save the QR code image

    return qr_image

def convert_qr_to_xbm(image_path, xbm_file, resolution=(70, 70)):
    img = Image.open(image_path)

    # Change the resolution if needed
    img = img.resize(resolution)  # Use resample parameter

    # Convert the image to monochrome
    img = img.convert("1")  # "1" mode for 1-bit pixels, representing black and white

    # Save the XBM image
    img.save(xbm_file)

    return xbm_file

def generate_and_convert_upi_qr(vpa, name, amount, currency="INR", message="", qr_resolution=(70, 70), bitmap_resolution=(70, 70)):
    # Generate UPI QR code
    qr_image = generate_upi_qr_code(vpa, name, amount, currency, message)

    # Save the QR code image
    qr_image_path = "upi_qr_code.png"
    qr_image.save(qr_image_path)

    # Create folder based on VPA name
    folder_name = vpa.replace('@', '_').replace('.', '_')
    if not os.path.exists(folder_name):
        os.makedirs(folder_name)

    # Convert QR code to XBM
    xbm_file = os.path.join(folder_name, "upi_qr_code.xbm")
    convert_qr_to_xbm(qr_image_path, xbm_file, resolution=bitmap_resolution)

    # Remove the temporary QR code image
    os.remove(qr_image_path)

    return xbm_file

vpa = "pos.5255351@indus"  
name = "CLOTH BAG VENDING MACHINE"  
amount = "1.0"  
message = "Payment for CLoth Bag" 
xbm_path = generate_and_convert_upi_qr(vpa, name, amount, message=message)
print("XBM image saved at:", xbm_path)
