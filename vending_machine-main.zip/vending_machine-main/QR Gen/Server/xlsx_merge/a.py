import pandas as pd

# Read the first Excel file
df1 = pd.read_excel("f1.xlsx")

# Read the second Excel file
df2 = pd.read_excel("f2.xlsx")

# Merge the two DataFrames based on the common column
merged_df = pd.merge(df1, df2, how='inner', right_on='Merchant_Contact', left_on='Mobile_No')

# Write the merged DataFrame to a new Excel file
merged_df.to_excel("merged_file.xlsx", index=False)
