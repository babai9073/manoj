def hex_to_bytes(hex_string):
    # Remove non-hex characters and pad the string with 0 if the length is odd
    hex_string = ''.join(filter(str.isalnum, hex_string))
    if len(hex_string) % 2 != 0:
        hex_string += '0'

    # Convert hex string to bytes
    return bytes.fromhex(hex_string)

def decode_pdu(pdu):
    try:
        # Convert PDU string to bytes
        pdu_binary = hex_to_bytes(pdu)

        # Ensure the PDU is of sufficient length
        if len(pdu_binary) < 2:
            raise ValueError("PDU string is too short")

        # Extract SMSC information
        smsc_length = pdu_binary[0]
        if len(pdu_binary) < smsc_length + 2:
            raise ValueError("SMSC information is missing")
        
        smsc_number = pdu_binary[1:1 + (smsc_length + 1) // 2].hex()
        smsc_type = pdu_binary[1 + (smsc_length + 1) // 2] & 0x03

        # Extract sender's number (source address)
        sender_length_index = 1 + (smsc_length + 1) // 2 + 1
        if len(pdu_binary) < sender_length_index + 1:
            raise ValueError("Sender length information is missing")

        sender_length = pdu_binary[sender_length_index]
        if len(pdu_binary) < sender_length_index + 2 + (sender_length + 1) // 2:
            raise ValueError("Sender number information is missing")

        sender_number = pdu_binary[sender_length_index + 1:sender_length_index + 2 + (sender_length + 1) // 2].hex()

        # Extract timestamp
        timestamp_index = sender_length_index + 2 + (sender_length + 1) // 2
        if len(pdu_binary) < timestamp_index + 1:
            raise ValueError("Timestamp length information is missing")

        # timestamp_length = pdu_binary[timestamp_index]
        # if len(pdu_binary) < timestamp_index + 1 + timestamp_length:
        #     raise ValueError("Timestamp information is missing")

        # timestamp = pdu_binary[timestamp_index + 1:timestamp_index + 1 + timestamp_length].hex()

        # Extract message
        # message_index = timestamp_index + 1 + timestamp_length
        # if len(pdu_binary) < message_index + 1:
        #     raise ValueError("Message length information is missing")

        # message_length = pdu_binary[message_index]
        # if len(pdu_binary) < message_index + 1 + message_length:
        #     raise ValueError("Message content is missing")

        # message = pdu_binary[message_index + 1:].decode("utf-8")

        return smsc_number, sender_number
    except Exception as e:
        print("Error decoding PDU:", e)
        return None, None, None, None

# Sample PDU data
pdu_data = "07914487651000F044D0180019071028003AA00000010122110228373873F30000AE8329BFD06"

# Decode the PDU
smsc_number, sender_number = decode_pdu(pdu_data)

# Print the decoded information
if smsc_number is not None:
    print("SMSC Number:", smsc_number)
    print("Sender Number:", sender_number)
   