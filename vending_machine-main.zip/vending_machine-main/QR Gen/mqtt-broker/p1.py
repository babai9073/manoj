import paho.mqtt.broker as mqtt


def on_connect(client, userdata, flags, rc):
    print(f"Client {client} connected with result code {rc}")

def on_disconnect(client, userdata, rc):
    print(f"Client {client} disconnected with result code {rc}")

def on_message(client, userdata, msg):
    print(f"Received message on topic {msg.topic}: {msg.payload.decode()}")

broker = mqtt.Mosquitto()
broker.on_connect = on_connect
broker.on_disconnect = on_disconnect
broker.on_message = on_message

broker_address = "localhost"
broker_port = 1883

broker.listen(broker_address, broker_port)
print(f"MQTT broker listening on {broker_address}:{broker_port}")

try:
    broker.loop_forever()
except KeyboardInterrupt:
    print("MQTT broker stopped")
