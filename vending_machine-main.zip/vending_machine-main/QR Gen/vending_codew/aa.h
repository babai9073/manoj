#include <SoftwareSerial.h>

SoftwareSerial sim800l(10, 11); // RX, TX pins

void setup()
{
    Serial.begin(9600);
    sim800l.begin(9600);
    delay(1000);

    // Enable text mode for SMS messages
    sim800l.println("AT+CMGF=1");
    delay(100);

    // Read all available messages
    sim800l.println("AT+CMGL=\"ALL\"");
    delay(1000);

    // Parse and extract the last message
    String lastMessage;
    while (sim800l.available())
    {
        String response = sim800l.readStringUntil('\n');
        if (response.startsWith("+CMGL:"))
        {
            lastMessage = response.substring(response.indexOf(',') + 1);
        }
    }

    // Print the last message
    Serial.println("Last Message: " + lastMessage);
}

void loop()
{
    // Your code here
}
