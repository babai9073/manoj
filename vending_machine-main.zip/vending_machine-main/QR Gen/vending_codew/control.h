const int motor[] = {14, 27, 26, 25, 33, 32, 19, 21};
const int coin_enable_pin = 1;
const int ir_pin = 4;
const int collector = 2;
const int buzzer = 15;
int vend_delay = 500;
volatile bool irSwitchState = LOW;  
volatile bool coinDetected = false;  // Variable to track if a coin is detected

int flag_bag = 0;

void init_func()
{
  pinMode(coin_enable_pin, OUTPUT);
  digitalWrite(coin_enable_pin, 1);
  pinMode(buzzer,OUTPUT);
  for (int i = 0; i < 8; i += 1)
  {
    pinMode(motor[i], OUTPUT);
    digitalWrite(motor[i], 1);
  }
  pinMode(ir_pin,INPUT);
  pinMode(collector,INPUT);

  attachInterrupt(digitalPinToInterrupt(ir_pin), handleInterrupt_ir, CHANGE);
  attachInterrupt(digitalPinToInterrupt(coinPin), handleInterrupt, CHANGE);

  
}

void vend_motor(int rack_no)
{
  digitalWrite(motor[rack_no], 0);
  delay(vend_delay);
  digitalWrite(motor[rack_no], 1);
}


void handleInterrupt_ir() {
  int reading = digitalRead(ir_Pin);
  irSwitchState = reading;
  if (irSwitchState == HIGH) {
    digitalWrite(buzzer, LOW);
  } else {
    digitalWrite(buzzer, HIGH);
    flag_bag = 1;
  }
}


void handleInterrupt_coin() {
  int reading = digitalRead(collector);
  coinDetected = (reading == HIGH);
  if (coinDetected) {
    digitalWrite(buzzer, 0); 
  
  } else {
    digitalWrite(buzzer, 1);   // Turn off the action
  }
}
