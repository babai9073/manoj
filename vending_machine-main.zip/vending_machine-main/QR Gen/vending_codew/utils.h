String PHONE = "";
String msg = "";


void smsRead(){

  Serial2.println("AT");
  Serial2.println("AT+CMGF=1");
  Serial2.println("AT+CNMI=1,2,0,0,0");
  delay(2000);
  }

std::pair<String, String> parseData(String buff) {
  PHONE="";
  msg="";

  unsigned int index;


  index = buff.indexOf("\r");
  buff.remove(0, index + 2);
  buff.trim();

  if (buff != "OK") {
    index = buff.indexOf(":");
    String cmd = buff.substring(0, index);
    cmd.trim();

    buff.remove(0, index + 2);

    
    if (cmd == "+CMT") {
      index = buff.lastIndexOf(0x0D);
      msg = buff.substring(index + 2, buff.length());      
      msg.toLowerCase();
      index = buff.indexOf(0x22);
      PHONE = buff.substring(index + 1, index + 14);
    }
  }
  return std::make_pair(msg, PHONE);
}
